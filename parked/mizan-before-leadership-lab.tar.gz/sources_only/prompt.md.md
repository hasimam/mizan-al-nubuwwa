Create a single-page Arabic infographic poster titled "ميزان النبوة" (The Scale of Prophethood) that compares John Maxwell's 21 Laws of Leadership with the Prophetic Methodology (المنهاج النبوي).

═══════════════════════════════════════════════════════════

1. TITLE & HEADER
   ═══════════════════════════════════════════════════════════

Main Title (large, centered, top):
☾❋☽ ميزان النبوة ☾❋☽

Subtitle (medium, centered, below title):
القوانين الـ21 للقيادة في ضوء المنهاج النبوي

Decorative line under subtitle:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

═══════════════════════════════════════════════════════════ 2. LAYOUT
═══════════════════════════════════════════════════════════

Single page (A4 portrait, 2480x3508 px at 300 DPI, or 1080x1350 for social media).
Content divided into 4 equal quadrants (2x2 grid) in the middle section.
Top: title + subtitle.
Bottom: two summary boxes (القاعدة الجامعة + خلاصة الحكم).

═══════════════════════════════════════════════════════════ 3. THE FOUR QUADRANTS (2x2 Grid)
═══════════════════════════════════════════════════════════

Each quadrant has:

- An icon/emoji at top
- A group title in Arabic
- A numbered list of laws (short Arabic phrases only)

┌─────────────────────────┬─────────────────────────┐
│ 🏛️ قوانين الأساس │ 🤝 قوانين التمكين │
│ ١. التأثير │ ٦. الأرض الصلبة │
│ ٢. الأولويات │ ٧. الاحترام │
│ ٣. الثقة │ ٨. الحدس │
│ ٤. الاتصال │ ٩. المغناطيسية │
│ ٥. الإضافة │ ١٠. الارتباط │
├─────────────────────────┼─────────────────────────┤
│ ⚔️ قوانين القيادة الفاعلة│ 🌱 قوانين الأثر والاستدامة│
│ ١١. الدائرة المقربة │ ١٦. الزخم │
│ ١٢. التفويض │ ١٧. الأولويات │
│ ١٣. الصورة │ ١٨. التضحية │
│ ١٤. الشراء │ ١٩. التوقيت │
│ ١٥. النصر │ ٢٠. النمو المطرد │
│ │ ٢١. الإرث │
└─────────────────────────┴─────────────────────────┘

═══════════════════════════════════════════════════════════ 4. BOTTOM SECTION — TWO BOXES
═══════════════════════════════════════════════════════════

Box 1 — القاعدة الجامعة (The Comprehensive Rule):
المنهاج النبوي أصل وميزان، وقوانين ماكسويل فرع ومادة.
نأخذ منها ما يوافق الشرع، ونردّ ما يخالف،
ونضيف ما هو أعلى: الأمانة، والإخلاص، والاحتساب، والثواب.

Box 2 — خلاصة الحكم (The Verdict):
ماكسويل: كيف تكون قائداً ناجحاً؟
المنهاج النبوي: كيف تكون عبداً صادقاً أميناً؟
فخذ من الأول ما يوافق الثاني، ولا تجعل الثاني تابعاً للأول.

Footer (bottom center):
والحمد لله رب العالمين

═══════════════════════════════════════════════════════════ 5. DESIGN SPECIFICATIONS
═══════════════════════════════════════════════════════════

COLORS:

- Background: warm beige #F8F5F0
- Primary: dark green #1B4332 OR navy #1B263B
- Accent: gold #C9A227
- Text: dark charcoal #2B2B2B
- Quadrant backgrounds: light cream #FFFDF8 with gold border
- Bottom boxes: pale green #E8F0E8 or pale gold #F5EDD6

TYPOGRAPHY:

- Arabic font: "Amiri" for titles, "Cairo" or "Tajawal" for body
- Title: 48-60pt, bold, gold or dark green
- Subtitle: 28-32pt, regular
- Group titles: 24pt, bold, dark green
- Law items: 18-20pt, regular, charcoal
- Bottom boxes text: 16-18pt

DECORATIVE ELEMENTS:

- Islamic geometric border frame around entire page
- Ornamental dividers between sections (❈ ✦ ☾ ❋)
- Crescent moon and star motifs in corners
- Subtle arabesque pattern in background (very light opacity)

ICONS (in each quadrant corner):

- 🏛️ قوانين الأساس (Foundation)
- 🤝 قوانين التمكين (Empowerment)
- ⚔️ قوانين القيادة الفاعلة (Effective Leadership)
- 🌱 قوانين الأثر والاستدامة (Legacy & Sustainability)

═══════════════════════════════════════════════════════════ 6. TECHNICAL NAVIGATION TIPS FOR THE AGENT
═══════════════════════════════════════════════════════════

APPROACH:

- Use HTML + CSS (single .html file) with RTL direction
- Or Python with ReportLab / Pillow for image output
- Or SVG generation for scalable output
- Ensure Arabic text renders correctly (use Google Fonts: Amiri + Cairo)

STEPS:

1. Set up HTML structure with dir="rtl" lang="ar"
2. Import Google Fonts: Amiri, Cairo
3. Create CSS Grid: 2x2 for quadrants, full-width for header/footer
4. Add Islamic border using CSS border-image or SVG pattern
5. Insert icons using emoji or SVG
6. Style all text with specified colors and fonts
7. Test rendering in browser (Safari on Mac)
8. Export as PDF (Print > Save as PDF) or PNG (screenshot)

FALLBACK:

- If emoji don't render well, use SVG icons instead
- If Arabic fonts fail, use system fonts: "Geeza Pro" (Mac) or "Arial"
- If layout breaks, use flexbox instead of grid

OUTPUT FILE:
Save as: mizan-al-nubuwwa.html
Then open in Safari → Print → Save as PDF → mizan-al-nubuwwa.pdf

═══════════════════════════════════════════════════════════ 7. FINAL CHECKLIST
═══════════════════════════════════════════════════════════

✅ Title in Arabic: ميزان النبوة
✅ Subtitle: القوانين الـ21 للقيادة في ضوء المنهاج النبوي
✅ 4 quadrants with icons and numbered laws (1-21)
✅ Bottom: 2 summary boxes
✅ Islamic decorative frame
✅ RTL text direction
✅ Arabic fonts (Amiri + Cairo)
✅ Colors: green, gold, beige
✅ Export as PDF or PNG
✅ Test in Safari on Mac

═══════════════════════════════════════════════════════════
END OF PROMPT
═══════════════════════════════════════════════════════════
